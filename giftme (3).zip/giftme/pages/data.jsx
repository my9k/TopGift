
import img1 from './asset/w1.png'
import img2 from './asset/w2.png'
import img3 from './asset/w3.png'
import img4 from './asset/w4.png'
export const data = {
    "men" : [
        {
            "title" : "Watch",
            "price" : "250",
            "image" : img1,
            "image2" : img2,
            "image3" : img3,
            "image4" : img4,
        },
        {
            "title" : "Mobile",
            "price" : "250",
            "image" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/m/p/r/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfjfsyjfgs.jpeg?q=70',
            "image2" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/k/z/t/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mf34mfn8cy.jpeg?q=70',
            "image3" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/g/1/i/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfpgjnnvzn.jpeg?q=70',
            "image4" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/r/r/c/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfgpfnehqy.jpeg?q=70',
        },
        {
            "title" : "Watch",
            "price" : "250",
            "image": "https://rukminim1.flixcart.com/image/832/832/k6mibgw0/diary-notebook/9/h/m/escape-escape-diary-friends-forever-1009-original-imafpyrqzngeenca.jpeg?q=70",
            "image2": "https://rukminim1.flixcart.com/image/416/416/k6l2vm80/diary-notebook/9/h/m/escape-diary-friends-forever-1009-original-imafpyrqcyejjt85.jpeg?q=70",
            "image3": "https://rukminim1.flixcart.com/image/416/416/k73nlow0/diary-notebook/b/e/n/escape-escape-diary-top-secret-stamp-diary-ruled-vintage-diary-original-imafpe85uzebbhtg.jpeg?q=70",
            "image4": "https://rukminim1.flixcart.com/image/416/416/k6mibgw0/diary-notebook/9/h/m/escape-escape-diary-friends-forever-1009-original-imafpfh8jfqdrgrk.jpeg?q=70"

        },
        {
            "title" : "Watch",
            "price" : "250",
            "image": "https://rukminim1.flixcart.com/image/832/832/l58iaa80/pen/n/y/r/-original-imagfyfbryayzx9r.jpeg?q=70",
            "image2": "https://rukminim1.flixcart.com/image/832/832/l58iaa80/pen/1/a/m/-original-imagfyfbss7j6nz7.jpeg?q=70",
            "image3": "https://rukminim1.flixcart.com/image/832/832/l58iaa80/pen/v/j/r/-original-imagfyfbzmrbxjtw.jpeg?q=70",
            "image4": "https://rukminim1.flixcart.com/image/832/832/l58iaa80/pen/u/r/3/-original-imagfyfbna4wffm8.jpeg?q=70"

        },
        {
            "title" : "Watch",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        }    
    ],
    "women" : [
        {
            "title" : "Nailpaint",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Mobile",
            "price" : "250",
            "image" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/m/p/r/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfjfsyjfgs.jpeg?q=70',
            "image2" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/k/z/t/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mf34mfn8cy.jpeg?q=70',
            "image3" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/g/1/i/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfpgjnnvzn.jpeg?q=70',
            "image4" : 'https://rukminim1.flixcart.com/image/832/832/kc29n680/headphone/r/r/c/ath-m30x-professional-monitor-headphones-audio-technica-original-imaft9mfgpfnehqy.jpeg?q=70',
        },
        {
            "title" : "Mobile",
            "price" : "250",
            "image": "https://m.media-amazon.com/images/I/51ya444rsTL._SX679_.jpg",
            "image2": "https://m.media-amazon.com/images/I/615SohxfxPL._SX679_.jpg",
            "image3": "https://m.media-amazon.com/images/I/71iwPiSnUNL._SY879_.jpg",
            "image4": "https://m.media-amazon.com/images/I/614Ht3IYV5S._SX679_.jpg"

        },
        {
            "title" : "Watch",
            "price" : "250",
            "image": "https://rukminim1.flixcart.com/image/832/832/kyxb9u80/backpack/m/q/4/girls-college-school-backpack-tts-backpack-cream-backpack-tts-original-imagbfvasccv928u.jpeg?q=70",
            "image2": "https://rukminim1.flixcart.com/image/832/832/kyxb9u80/backpack/y/3/k/girls-college-school-backpack-tts-backpack-blue-backpack-tts-original-imagbfvauwrmkpvh.jpeg?q=70",
            "image3": "https://rukminim1.flixcart.com/image/832/832/kyxb9u80/backpack/c/k/p/girls-college-school-backpack-tts-backpack-maroon-backpack-tts-original-imagbfvaatsb8ynn.jpeg?q=70",
            "image4": "https://rukminim1.flixcart.com/image/832/832/kyxb9u80/backpack/r/s/o/girls-college-school-backpack-tts-backpack-pink-backpack-tts-original-imagbfvaq3xnd9q6.jpeg?q=70"
        
        },
        {
            "title" : "Rubber",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Eye liner",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        }    
    ],
    "children" : [
        {
            "title" : "Toys",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Teddy Bear",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Train",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Animal",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        },
        {
            "title" : "Clothes",
            "price" : "250",
            "image" : img1,
            "image2" : img1,
            "image3" : img1,
            "image4" : img1,
        }    
    ]
}