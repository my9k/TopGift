import React from 'react'
import { useSelector } from 'react-redux'

function FormProducts() {
  const data = useSelector(state=>state.formReducer.data)
  console.log(data);
    return (
    <div>
      Form
    </div>
  )
}

export default FormProducts
