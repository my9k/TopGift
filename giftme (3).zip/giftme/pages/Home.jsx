import React from 'react'

import Card from './Card'
import Banner from './Banner'
import Gform from './Gform'


function Home() {
  return (
    
    <div className='container-fluid backColor'>
    <Gform />
     
     <div >
      <h3 className='after-pic' style={{padding:'20px 0',color:'#7c0000',fontFamily:'Garamond', fontWeight:'bold'}}>Give your favourite person a gift of his personality.</h3>
      <h6 style={{color:'#7c0000', fontFamily:'Papyrus', fontWeight:'bold'}} >Having problem while choosing a gift ?</h6>
      <h2 style={{padding:'5px 0',color:'#7c0000',fontFamily:'Garamond', fontWeight:'bold'}}>We are here to help you</h2>
      <br />
      <Banner/>
      </div>
      <div className="container">
      <h1 style={{padding:'10px 0',color:'#7c0000', marginLeft:'28px'}}>Top gifts for men</h1>
      <Card category = 'men'/>
     </div>
      <br></br>
      <div className='container'>
      <h1 style={{padding:'10px 0',color:'#7c0000', marginLeft:'28px'}}>Top gifts for Women</h1>
      <Card category = 'women'/>
     </div>
      <div className='container'>
      <h1 style={{padding:'10px 0',color:'#7c0000', marginLeft:'28px'}}>Top gifts for Children</h1>
      <Card category = 'children'/>
     </div>
     <hr style={{width:'100%'}}/>     
      </div>


  )
}

export default Home