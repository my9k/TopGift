import React from 'react'
import { useSelector } from 'react-redux';
import CustomCard from './CustomCard';
import { data } from "./data";
function Products() {
  const men = data.men;
  const women = data.women;
  const childern = data.children
  const value = useSelector((state) => state.searchReducer.data)
  const filteredValueMen = men.filter(r=>r.title.toLowerCase()===value.toLowerCase())
  const filteredValueWomen = women.filter(r=>r.title.toLowerCase()===value.toLowerCase())
  const filteredValueChildern = childern.filter(r=>r.title.toLowerCase()===value.toLowerCase())
  return (
    <div style={{display:'flex', flexWrap:'wrap',float:'left'}} className="container">
      {filteredValueMen.map((r, i) => {
        return <CustomCard key = {i} image1 = {r.image} image2 = {r.image2} image3 = {r.image3} image4 = {r.image4} title = {r.title} price = {r.price}/>
})}
      {filteredValueWomen.map((r, i) => {
        return <CustomCard key = {i} image1 = {r.image} image2 = {r.image2} image3 = {r.image3} image4 = {r.image4} title = {r.title} price = {r.price}/>
})}
      {filteredValueChildern.map((r, i) => {
        return <CustomCard key = {i} image1 = {r.image} image2 = {r.image2} image3 = {r.image3} image4 = {r.image4} title = {r.title} price = {r.price}/>
})}
    </div>
  )
}

export default Products