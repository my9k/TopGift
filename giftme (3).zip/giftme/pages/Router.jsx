import React from 'react'
import Home from './Home'
import Header from './Header'

import Footer from './Footer'
function Routers() {
  return (
    <>
      <Header/>
      <Home/>
        <hr style={{width:'100%'}}/>
        <Footer/>
    </>
  )
}

export default Routers
