import React from 'react'

function About() {
  return (
    <div className='container-fluid'>
        About
    </div>
  )
}

export default About
