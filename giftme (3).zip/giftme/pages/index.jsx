import React from 'react'
import Routers from './Router'
function index() {
  return (
    
      <Routers/>
    
  )
}

export default index
