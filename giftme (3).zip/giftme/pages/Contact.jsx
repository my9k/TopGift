import React from 'react'

function Contact() {
  
  return (
    <div className='container-fluid'>
      Contact Us
      <br />
    </div>
  )
}

export default Contact
