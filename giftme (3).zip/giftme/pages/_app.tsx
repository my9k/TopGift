import '../styles/globals.css'
import '../styles/Header.css'
import '../styles/Banner.css'
import '../styles/Footer.css'
import '../styles/Gform.css'
import '../styles/Home.css'
import 'bootstrap/dist/css/bootstrap.css'
import type { AppProps } from 'next/app'
import { Provider } from 'react-redux'
import store from '../redux/store'
import { useEffect } from "react";

export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    require("bootstrap/dist/js/bootstrap.bundle.min.js");
  }, []);
  return (
    <>
    <Provider store={store}>
    <Component {...pageProps} />
    </Provider>
  </>
  )
}
