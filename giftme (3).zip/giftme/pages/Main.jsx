import React from 'react'

function Main() {
  return (
    <div>
      Main
    </div>
  )
}

export default Main
