import { useRouter } from 'next/router';
import React from 'react'
import { useState } from 'react'
import { useDispatch } from 'react-redux';
import Link from 'next/link';
import { searchedValue } from '../redux/action';


function Header() {
  const dispatch = useDispatch()
  const [searchValue, setSearchValue] = useState('');
  const navigate = useRouter()
  
  const searchButton  = async (e) =>{
    e.preventDefault()
    dispatch(searchedValue(searchValue));
    setSearchValue('')
    navigate.push('/SearchProducts')
  }
  return (
    <div style={{position:'sticky',top:'0', width:'100%',zIndex:'100'}}>
      <nav className="navbar navbar-expand-lg bgColor navbar-dark" >
  <div className="container-fluid">
    <Link className="navbar-brand" href='/'>GiftMe</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <Link className="nav-link" aria-current="page" href='/'>Home</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" href='/About'>About Us</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" href='/Contact'>Contact Us</Link>
        </li>
      </ul>
      <form className="d-flex" role="search">
        <input className="form-control me-2" value={searchValue} type="search" placeholder="Search" onChange={e =>setSearchValue(e.target.value)} aria-label="Search" />
        <button className="btn btn-outline-light" type="submit" onClick={searchButton}>Search</button>
      </form>
    </div>
  </div>
</nav>
    </div>
  )
}

export default Header
