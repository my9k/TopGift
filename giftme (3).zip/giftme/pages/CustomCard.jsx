import React, { useState } from 'react'
import icon from './asset/star2.png'
import Image from 'next/image'
// import {Rate} from "antd";

function CustomCard(props) {
    const[img,setimg] = useState(props.image1);
    return (
        <div className="card mx-3 my-2 " style={{width: "15rem", height:'auto'}} key={props.index}>
        <section className="container">
        <div>
          <div>
          <img src={img} className="card-img-top pd-1 my-2" id="mainimg" height="220px" alt="..." />
  
          <div className="small-img-group" style={{display:'flex', justifyContent:'space-between', marginTop:'2px'}}>
             <div className="small-img-col" style={{cursor:'pointer', border:'1px ridge #ecdddd'}}>
                <img src={props.image1} style={{height:'3rem', width: '3rem'}} width="100%" className="small-img" id="s-img1" onClick={()=>setimg(props.image1)} alt=""/>
             </div>
             <div className="small-img-col" style={{cursor:'pointer', border:'1px ridge #ecdddd'}}>
                <img src={props.image2} style={{height:'3rem', width: '3rem'}} width="100%" className="small-img" id="s-img2" onClick={()=>setimg(props.image2)} alt=""/>
             </div>
             <div className="small-img-col" style={{cursor:'pointer', border:'1px ridge #ecdddd'}}>
                <img src={props.image3} style={{height:'3rem', width: '3rem'}} width="100%" className="small-img" id="s-img3" onClick={()=>setimg(props.image3)}  alt=""/>
             </div>
             <div className="small-img-col" style={{cursor:'pointer', border:'1px ridge #ecdddd'}}>
                <img src={props.image4} style={{height:'3rem', width: '3rem'}} width="100%" className="small-img" id="s-img4" onClick={()=>setimg(props.image4)} alt=""/>
             </div>
          </div>
          </div>
          </div>
        </section>
        <div className="card-body">
        <h7 className="card-title" style={{fontSize:'14px'}}><b>{props.title}</b></h7><br></br>
        <h7 className="card-text">Rs. {props.price}</h7><br></br>
        <h7> <button className='btn btn-warning btn-sm' style={{padding:'0px 1px 0px 1px', margin:'0px'}}><small style={{fontSize:'10px', margin:'0px'}}>{props.rating} &nbsp;<Image src={icon} style={{height:'15px', width:'15px', marginBottom:'2px'}} alt="..." /></small></button>
         {/* <Rate defaultValue={3.9} allowHalf disabled /><br></br> */}
         {/* <small style={{fontSize:'9px', color:'#7c0000', marginLeft:'60px'}}><b>4.3</b></small> */}
          <small style={{marginLeft:'10px', fontFamily:'Courier New'}}> {props.userRating} Ratings </small>
          </h7><br></br>
         <h7 style={{fontSize:'11px', fontFamily:'Garamond'}}> <b>Description</b> <div>{props.desc}.<i className="fa fa-star-o"/></div>
            </h7><br></br>
          
          <div style={{justifyContent:'centre', marginLeft:'30px', bottom:'0'}}>
        <a href={props.button} className="btn btn-danger" target='_blank'>{props.site}</a>
        </div>
      </div>
    </div>
      )
}

export default CustomCard
