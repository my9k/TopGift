import React from 'react'
import Link from 'next/link'

function Footer() {
  return (
    <div>
<footer className="mainFooter text-center text-lg-start text-muted ">
 
  <section className="d-flex justify-content-center justify-content-lg-between p-4 border-bottom bg-dark" style={{color:"white"}}>
  
    <div className="me-5 d-none d-lg-block ">
      <span>Get connected with us on social networks:</span>
    </div>
    <div>
      <Link href="/" className='me-4' style={{color:"#3b5998"}} role="button">
        <i className="fab fa-facebook-f fa-lg"></i>
      </Link>

       
      <Link href="/" className="me-4" style={{color:"#55acee"}} role="button">
        <i className="fab fa-twitter fa-lg"></i>
      </Link>
      <Link href="/" className="me-4" style={{color:"#dd4b39"}} role="button">
        <i className="fab fa-google fa-lg"></i>
      </Link>
      <Link href="/" className="me-4" style={{color:"#ac2bac"}} role="button">
        <i className="fab fa-instagram fa-lg"></i>
      </Link>
      <Link href="/" className="me-4" style={{color:"#0077b5"}} role="button">
        <i className="fab fa-linkedin fa-lg"></i>
      </Link>
    </div>
  </section>
  <section className="second-footer">
    <div className="container text-center text-md-start mt-5">
      <div className="row mt-3">
        <div className="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <h6 className="text-uppercase fw-bold mb-4">
            <i className="fas fa-gem me-3"></i>Gift Me
          </h6>
          <p>
            Our purpose here is to help customer to choose best gift for their loved ones. We are not responsible for any external
            sites error.
          </p>
        </div>
        <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <h6 className="text-uppercase fw-bold mb-4">
            Get to know Us
          </h6>
          <p>
            <Link href="#!" className="text-reset">About Us</Link>
          </p>
          <p>
            <Link href="#!" className="text-reset">Our Team</Link>
          </p>
        
        </div>
        <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <h6 className="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <Link href="#!" className="text-reset">Birthday</Link>
          </p>
          <p>
            <Link href="#!" className="text-reset">Friend</Link>
          </p>
          <p>
            <Link href="#!" className="text-reset">Couple</Link>
          </p>
          <p>
            <Link href="#!" className="text-reset">Anniversary</Link>
          </p>
        </div>

        <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

          <h6 className="text-uppercase fw-bold mb-4">Contact</h6>
          <p><i className="fas fa-home me-3"></i> New York, NY 10012, US</p>
          <p>
            <i className="fas fa-envelope me-3"></i>
            info@example.com
          </p>
          <p><i className="fas fa-phone me-3"></i> + 01 234 567 88</p>
          <p><i className="fas fa-print me-3"></i> + 01 234 567 89</p>
        </div>

      </div>

    </div>
       <p className='text-center p-4'> © 2022 Copyright: <Link className="text-reset fw-bold" href="https://mdbootstrap.com/">GiftMe.com</Link></p>

  </section>

</footer>
</div>
    
  )
}

export default Footer
