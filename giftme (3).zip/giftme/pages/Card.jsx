import axios from "axios";
import React, { useEffect, useState } from "react";
import CustomCard from "./CustomCard";
import { data } from "./data";
function Card( props) {
  const choice = props.category;
  // const men = data.men;
  // const women = data.women;
  const children = data.children;
  const[mendata,setData]  = useState([])
  const[womendata,setwomendata] = useState([])
  useEffect(()=>{
  axios.get('https://my-json-server.typicode.com/LakhanShanker/giftapi/men')
  .then(res => res.data)
  .then(x => setData(x))
  },[])
  useEffect(()=>{
    axios.get('https://my-json-server.typicode.com/LakhanShanker/giftapi/products')
    .then(res => res.data)
    .then(x => setwomendata(x))
  },[])



  const Men = () => mendata.map((r, i) => {
    return <CustomCard index = {i} 
    image1 = {r.image1} 
    image2 = {r.image2} 
    image3 = {r.image3} 
    image4 = {r.image4} 
    title = {r.title} 
    price = {r.price}
    rating = {r.rating}
    userRating = {r.userRating}
    desc = {r.desc}
    button = {r.button}
    site = {r.site}
    />
  })
  const Women = () => womendata.map((r, i) => {
   return <CustomCard index = {i} 
   image1 = {r.image1} 
   image2 = {r.image2} 
   image3 = {r.image3} 
   image4 = {r.image4} 
   title = {r.title} 
   price = {r.price}
   rating = {r.rating}
   userRating = {r.userRating}
   desc = {r.desc}
   button = {r.button}
   site = {r.site}
   /> 
  })
  const Children = () => children.map((r, i) => {
    return <CustomCard index = {i} 
    image1 = {r.image} 
    image2 = {r.image2} 
    image3 = {r.image3} 
    image4 = {r.image4} 
    title = {r.title} 
    price = {r.price}/>
  })
  return (
    <div style={{display:'flex', flexWrap:'wrap',float:'left'}} className="container">
      {
      choice === 'men' ? <Men/>
      : props.category === 'women' ? <Women />
      : <Children />
  }
  </div>
  )
}

export default Card;
