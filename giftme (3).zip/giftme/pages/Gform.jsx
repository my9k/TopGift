import Link from 'next/link'
import { useRouter } from 'next/router'
import React from 'react'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { formSubmit } from '../redux/action'

function Gform() {
  const navigate = useRouter()
  const dispatch = useDispatch()
    const [val,setVal] = useState({
       gender: '',
       age: '',
       personality: '',
       price: '',
       occasion:'',
       relationship: '',
    })
     const[range,setRange] = useState(0)
     const handleChangeGender = (e) =>{
      const data = {
        ...val,
        [e.target.name] : e.target.value
      }
      setVal(data)
      if(e.target.name === 'price'){
        setRange(e.target.value)
      }
     }
     const handleSubmit = (e) =>{
      e.preventDefault()
      if(val.age==='' || val.gender==='' || val.occasion==="" || val.personality==="" || val.price==="" || val.relationship==="")
      alert("All fields are required")
      else{
        dispatch(formSubmit(val))
        setVal({
          gender:'',
          age:'',
          personality:'',
          price:'',
          occasion:'',
          relationship:''
        })

        document.getElementById("myForm").reset();
        navigate.push('/FormProducts')
      }
    }
      
    return (
   <div className='container' style={{position:'sticky',top:'60px',zIndex:'1'}}>
  <div className='belowHeader' style={{display: 'flex' ,justifyContent: 'center', gap:'20px'}}>
  <Link className="btn btn-danger" role="button" aria-expanded="false" style={{marginTop:'10px'}} href ='/'>Male</Link>
  <a className="btn btn-danger" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" style={{marginTop:'10px'}}>
 Customize your gift
  </a>
  <Link className="btn btn-danger" href ='/' style={{marginTop:'10px'}}>Female</Link>
  </div>
<div className="collapse collapseForm" id="collapseExample">
  <div className="card-body" style={{display:'flex',border:'2px solid #7c0000', margin:'10px'}}>
  <form  className='container' id="myForm">
  <fieldset className="form-group" style={{marginTop:'10px'}}  >
    <div className="row">
      <legend className="col-form-label col-sm-2"><span aria-label="required">Gender</span></legend>
      <div className="col-sm-2">
        
          <input className="form-check-input" type="radio" name="gender" id="gridRadios1" value="M" onChange={handleChangeGender} required/>
          <label  className="form-check-label" htmlFor="gridRadios1">
           Male 
          </label>
          <br />
          <input className="form-check-input" type="radio" name="gender" id="gridRadios2" value="F" onChange={handleChangeGender} required/>
          <label  className="form-check-label" htmlFor="gridRadios2">
          Female
          </label>
        </div>
    </div>
    
  </fieldset>
  <br></br>

  <fieldset className="form-group">
    <div className="row">
      <legend className="col-form-label col-sm-2 pt-0">Age</legend>
      <div className="col-sm-10">
      <select className="custom-select" onChange={handleChangeGender} name="age" required="required">
    <option value="">Please select age</option>
    <option value="5">between 1 to 10</option>
    <option value="15">between 11 to 20</option>
    <option value="25">between 21 to 30</option>
    <option value="35">between 31 to 40</option>
    <option value="45">between 41 to 50</option>
    <option value="50">Above 50</option>
  </select>
  
  </div>
    </div>
  </fieldset>
  <br></br>

  <fieldset className="form-group">
    <div className="row">
      <legend className="col-form-label col-sm-2 pt-0">Personality</legend>
      <div className="col-sm-10">
      <select className="custom-select" onChange={handleChangeGender} name='personality' required>
    <option value="">Please select Personality</option>
    <option value="Part Lover">Party Lover</option>
    <option value="Natural Lover">Natural Lover</option>
    <option value="Geek">Geek</option>
    <option value="Classy">Classy</option>
    <option value="Religious">Religious</option>
    <option value="Fitness Freak">Fitness Freak</option>
    <option value="Foodie">Foodie</option>  
    <option value="Traveler">Traveler</option>
  </select>
  </div>
    </div>
  </fieldset>
  <br></br>

  <fieldset className="form-group">
    <div className="row">
      <legend className="col-form-label col-sm-2 pt-0">Price Range</legend>
      <div className="col-sm-2">
      <input type="range" className="custom-range" min="100" max="5000" step="100" id="customRange1" onChange={handleChangeGender} name='price'/>
      <p className="slider-box">{range}-{range < 1500 ? range*1.5 : parseInt(range)+200}</p>
  </div>
    </div>
  </fieldset>
  <br></br>

  <fieldset className="form-group">
    <div className="row">
      <legend className="col-form-label col-sm-2 pt-0">Select Ocassion</legend>
      <div className="col-sm-10">
      <select className="custom-select" onChange={handleChangeGender} name='occasion'>
    <option value="">Please select Occasion</option>
    <option value="Birthday">Birthday</option>
    <option value="Anniversary">Anniversary</option>
    <option value="Wedding">Wedding</option>
    <option value="House Warming">House Warming</option>
    <option value="Best Wishes">Best Wishes</option>
  </select>
  </div>
    </div>
  </fieldset>
  <br></br>

  <fieldset className="form-group">
    <div className="row">
      <legend className="col-form-label col-sm-2 pt-0"> Relationship</legend>
      <div className="col-sm-10">
      <select className="custom-select" onChange={handleChangeGender} name='relationship'>
    <option value="">Please select Relationship</option>
    {
      val.gender === 'M' ?
    <>
    <option value="Husband">Husband</option>
    <option value="Father">Father</option>
    <option value="Boyfriend">Boyfriend</option>
    <option value="Brother">Brother</option>
    <option value="Son">Son</option>
    <option value="Friend">Friend</option>
    <option value="Grandfather">Grandfather</option>
    </>
    :
    <>
    <option value="Wife">Wife</option>
    <option value="Mother">Mother</option>
    <option value="Girlfriend">Girlfriend</option>
    <option value="Friend">Friend</option>
    <option value="Sister">Sister</option>
    <option value="Daughter">Daughter</option>
    <option value="Grandmother">Grandmother</option>
    </>
    }
  </select>
  </div>
    </div>
  </fieldset>
  <br />
  <div className="form-group row">
    <div className="col-sm-12">
      <button className="btn btn-danger" style={{marginBottom:'10px', marginLeft:'50px'}} onClick={handleSubmit}>Submit</button>
    </div>
  </div>
</form>
  </div>
</div>

</div>

  )
}

export default Gform
