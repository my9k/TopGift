export const add = (data) => {
    return{
            type: 'ADD',
            data
      }
    }
    export const searchedValue = (value) =>{
      return{
        type : 'SEARCH_VALUE',
        value
      }
    }
    
    export const formSubmit = (value) =>{
      return{
        type: 'FORM_DATA',
        data : value
      }
    }