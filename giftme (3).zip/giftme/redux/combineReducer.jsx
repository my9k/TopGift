import { combineReducers } from "redux";
import searchReducer from "./searchReducer";
import formReducer from "./formReducer";
import reducer from "./reducer";
const allReducer = combineReducers({
    reducer,
    searchReducer,
    formReducer
})

export default allReducer