const initialState = {
    data : {}
}
const formReducer = (state=initialState, action) => {
    switch(action.type){
        case 'FORM_DATA':
            return {
                ...state,
                data : action.data
            }
        default:
            return state
    }
}

export default formReducer