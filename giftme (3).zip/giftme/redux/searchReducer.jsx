const initialState = {
    data : ''
}
const searchReducer = (state=initialState, action) => {
    switch(action.type){
        case 'SEARCH_VALUE':
            return {
                ...state,
                data : action.value
            }
        default:
            return state
    }
}

export default searchReducer