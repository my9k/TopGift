import { legacy_createStore as createStore } from "redux";
import allReducer from "./combineReducer";

const store = createStore(allReducer)

export default store